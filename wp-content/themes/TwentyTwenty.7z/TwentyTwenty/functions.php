<?php function divi__child_them_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . './style.css' );

}
add_action( 'wp_enqueue_scripts', 'divi__child_them_enqueue_styles' ); ?>